#!/bin/sh


SCRIPT_DIR=$(cd $(dirname $0) && pwd)



pushd ${SCRIPT_DIR}
OPENSSL_VERSION=1.0.1e
FIPS_VERSION=2.0.5

OPENSSL_INSTALL_DIR=${SCRIPT_DIR}/openssl_install
FIPS_INSTALL=${SCRIPT_DIR}/fips_install

#OPENSSL_OPTIONS="threads no-shared no-hw no-dso no-krb5 no-zlib no-bf no-cast no-idea no-md2 no-mdc2 no-rc5 no-ripemd no-sctp"
OPENSSL_OPTIONS=""

rm -Rf ${OPENSSL_INSTALL_DIR}
rm -Rf ${FIPS_INSTALL}
rm -Rf openssl-fips-${FIPS_VERSION}
rm -Rf openssl-${OPENSSL_VERSION}

tar xzf openssl-fips-${FIPS_VERSION}.tar.gz
tar xzf openssl-${OPENSSL_VERSION}.tar.gz

FIPS_SIG=${SCRIPT_DIR}/openssl-fips-${FIPS_VERSION}/util/incore

. ./setenv-android.sh
echo "MACHINE=$MACHINE"
echo "SYSTEM=$SYSTEM"
echo "ARCH=$ARCH"


pushd openssl-fips-${FIPS_VERSION}
#Usage: Configure [no-<cipher> ...] 
#       [enable-<cipher> ...] [experimental-<cipher> ...] [-Dxxx] [-lxxx] [-Lxxx] [-fxxx] 
#       [-Kxxx] [no-hw-xxx|no-hw] [[no-]threads] [[no-]shared] [[no-]zlib|zlib-dynamic] 
#       [no-asm] [no-dso] [no-krb5] [386] [--prefix=DIR] [--openssldir=OPENSSLDIR] [--with-xxx[=vvv]] [--test-sanity] os/compiler[:flags]
./config --prefix=${FIPS_INSTALL}
#read -p "press any key to continue"
make || exit -1
make install || exit -1
cp ${FIPS_SIG} ${FIPS_INSTALL}/bin
popd



#read -p "press any key to continue"

. ./setenv-android.sh
pushd openssl-${OPENSSL_VERSION}
perl -pi -e 's/install: all install_docs install_sw/install: install_sw/g' Makefile.org
./config fips --with-fipsdir=${FIPS_INSTALL} --prefix=${OPENSSL_INSTALL_DIR}
make depend || exit -1
make || exit -1
make install CC=$ANDROID_TOOLCHAIN/arm-linux-androideabi-gcc RANLIB=$ANDROID_TOOLCHAIN/arm-linux-androideabi-ranlib
popd



popd





